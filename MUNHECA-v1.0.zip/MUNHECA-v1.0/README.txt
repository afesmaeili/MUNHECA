
MUNHECA uses the numpy and Scipy packages and does not need any installation. 

To run the code, a .txt file should be created which contains the input to the code. 
An example of the input file, the test.txt, is provided in the /Work directory.   

To run the Monte Carlo session, the following command can be used 

python [MUNHECA_PATH]/run/Main.py /[PATH/TO/INPUT]/[InputFileName].txt


After the execution, the results of this session will be saved, together with a copy 
of the input file, to the /results directory. The copied input file's name, depending on 
the chosen injection spectrum (Monochrome) or (PowerLaw) will be 0M_input.txt or 0S_input.txt, respectively.

To obtain the neutrino fluxes at the Earth the relevant syntaxes are:

python [MUNHECA_PATH]/run/nuSpec.py [MUNHECA_PATH]/results/[DESTINATION_DIR]/0M_input.txt

or

python [MUNHECA_PATH]/run/nuSpec_Weight.py [MUNHECA_PATH]/results/[DESTINATION_DIR]/0S_input.txt 

for (Monochrome) or (PowerLaw) injections, respectively. 

These commands end in creating a text file NEUTRINO_EARTH.txt in the same destination directory, 
which contains a table of the neutrinos fluxes, containing all-flavors and each flavor separately, at the Earth. 

The input file format is important and discrepancies may cause 'ValueErrors'.
A template is provided in /Work/ directory named test.txt

The letter capitalization and the place of the colons and the spaces are important in the input file.
Any parameter inside the input file should be followed by a colon (:) and a space ' '. 

For example: 

MPP: ON 

The input file contains four sets of parameters: 

1. The choice of processes in the cascade evolution.
2. The background photon field choice.
3. The injection settings.
4. The output files names and directory.

You will find these four sets in test.txt or see the MUNHECA paper for more detailed explanations.

 